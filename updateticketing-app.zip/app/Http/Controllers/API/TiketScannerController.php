<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ticket;
use App\Helpers\JsonFormatter;
use Illuminate\Support\Facades\DB;

class TiketScannerController extends Controller
{
    public function index()
    {
        
    }

    public function check_qr(Request $request)
    {
        
    }
}
